const page = () => {

    return (
        <div>AboutUs</div>
    );
};

export default page;